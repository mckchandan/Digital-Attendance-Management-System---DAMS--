<?php 
$conn=new mysqli("localhost","id4172165_damsonline1","damsonline","id4172165_subjects");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


 ?>