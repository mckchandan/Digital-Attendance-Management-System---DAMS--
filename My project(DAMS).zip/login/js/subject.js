   $(document).ready(function () {
       
    $("#semester").change(function () {
        var val1 = $("#semester").val();
        var val = $("#field").val();
        

        if (val != "" && val1 == "") {
            $("#subject").html(" <option >Please select Semester</option>");
        } else 
        if (val == "" && val1 != "") 
        {
            $('#field').change(function(){
            $('#semester').prop('selectedIndex',0);
            });
          $("#subject").html("<option >Please select Program</option>");
        } else 
        if (val == "Computer Science & Engg." && val1 == "4th") {
            $("#subject").html(" <option></option> <option >Tantrika Kannada-2</option> <option>Data structre using C</option> <option>OOP with Java</option> <option>Operating System</option> <option>Professional Ethics & Indian Constitution</option> <option>Data Structures lab</option> <option>OOP with Java Lab</option> <option>Linux lab</option>");
        } else if (val == "Computer Science & Engg." && val1 == "2nd") {
            $("#subject").html("<option></option> <option>Engineering Mathematics-II</option> <option>Communication Skills in English</option> <option>Digital  and Computer Fundamentals</option> <option>Digital Electronics Lab</option> <option>Basic Web Design Lab</option> <option>Multimedia Lab</option>");
        } else if (val == "Computer Science & Engg." && val1 == "6th") {
            $("#subject").html(" <option></option> <option>Software Testing</option> <option>Network Security Mgmt.</option> <option>Software Testing lab</option> <option>Network Security Lab</option> <option>Soft Skills for IT Professionals</option> <option>Internet of Things (IOT)</option> <option>Project Work- II</option> ");
        }

    });

$("#subject").change(function () {
      var code = $(this).val();
      
      if( code == "")
      {
        $("#subjid").html("<option></option>");
      }  else
      if( code == "Engineering Mathematics-II")
      {
        $("#subjid").html("<option>15SC02M</option>");
      } else
      if( code == "Communication Skills in English")
            {
              $("#subjid").html("<option>15CP01E</option>");
      } else
      if( code == "Digital  and Computer Fundamentals")
            {
              $("#subjid").html("<option>15CS21T</option>");
      } else
      if( code == "Digital Electronics Lab")
            {
              $("#subjid").html("<option>15EC03P</option>");
      } else
      if( code == "Basic Web Design Lab")
            {
              $("#subjid").html("<option>15CS22P</option>");
      } else
      if( code == "Multimedia Lab")
            {
              $("#subjid").html("<option>15CS23P</option>");
      } else
      if( code == "Tantrika Kannada-2")
      {
        $("#subjid").html("<option>15KA4KT</option>");
} else
if( code == "Data structre using C")
      {
        $("#subjid").html("<option>15CS41T</option>");
} else
if( code == "OOP with Java")
      {
        $("#subjid").html("<option>15CS42T</option>");
} else
if( code == "Operating System")
      {
        $("#subjid").html("<option>15CS43T</option>");
} else
if( code == "Professional Ethics & Indian Constitution")
      {
        $("#subjid").html("<option>15CS44T</option>");
} else
if( code == "Data Structures lab")
      {
        $("#subjid").html("<option>15CS45P</option>");
} else
if( code == "OOP with Java Lab")
      {
        $("#subjid").html("<option>15CS46P</option>");
} else
if( code == "Linux lab")
      {
        $("#subjid").html("<option>15CS47P</option>");
} else






if( code == "Software Testing")
      {
        $("#subjid").html("<option>15CS61T</option>");
} else
if( code == "Network Security Mgmt.")
      {
        $("#subjid").html("<option>15CS62T</option>");
} else
if( code == "Software Testing lab")
      {
        $("#subjid").html("<option>15CS64P</option>");
} else
if( code == "Network Security Lab")
      {
        $("#subjid").html("<option>15CS65P</option>");
} else
if( code == "Soft Skills for IT Professionals")
      {
        $("#subjid").html("<option>15CS66P</option>");
} else
if( code == "Project Work- II")
      {
        $("#subjid").html("<option>15CS67T</option>");
} else
if( code == "Internet of Things (IOT)")
      {
        $("#subjid").html("<option>15CS63F</option>");
}





    });
    
});