<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dams</title>
<meta name="description" content="">
<meta name="author" content="">

<!-- Favicons
    ================================================== -->
<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
<link rel="apple-touch-icon" href="img/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">
<link rel="stylesheet" href="addons/css/style.css">
  
<!-- Remove 000webhost banner -->    

<style>
            img[src="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]{
display:none;
}
</style>

<!-- Remove 000webhost banner -->    

<link rel="stylesheet" href="addons\pretty_css\pretty-checkbox-master\dist\pretty-checkbox.min.css">

<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>

<!-- Bootstrap -->
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.css">

<!-- Stylesheet
    ================================================== -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" type="text/css"  href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/prettyPhoto.css">
<link href='http://fonts.googleapis.com/css?family=Lato:400,700,900,300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800,600,300' rel='stylesheet' type='text/css'>

<link rel="stylesheet" type="text/css" href="addons\Additional animate_css\Sweet Alert\sweet-alert\sweetalert2.css">

<script type="text/javascript" src="js/modernizr.custom.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>    
    <![endif]-->
<script>
function hideloader() {       
  $(".loaded").fadeOut();
  $(".preloader").delay(1000).fadeOut("slow");
    };
  </script>

</head>
<body onload="hideloader()">


 <div class='preloader' ><div class='loaded' ><img class="dams_loader" align="center" src="/img/loader.gif"></div>&nbsp;</div> 





<!-- Navigation
    ==========================================-->
<nav id="menu" class="navbar navbar-default navbar-fixed-top">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand" href="index.php"><strong><i class="fa fa-sun-o"></i> Dams </strong></a> </div>
    
    
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
  <li><a href="#home" class="page-scroll">Home</a></li>

  <li><a href="#works-section" class="page-scroll">Portfolio</a></li>
  
  <li><a href="#team-section" class="page-scroll">Team</a></li>
  <li><a href="#about-section" class="page-scroll">About Us</a></li>
  <li><a href="#contact-section" class="page-scroll">Contact</a></li>     
  <a href="login"><li class="loginbutton">Log In</li></a>
  <a href="/signup"><li class="signupbutton">Sign Up</li></a>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container-fluid --> 
</nav>

<!-- Header -->
<header class="text-center" name="home">
  <div class="intro-text">
    <h1>Welcome to DAMS</h1>
    <p>Bring your Big Data to Digital Life With <strong > DAMS </strong> </p>
    <a href="#works-section" class="btn btn-default btn-lg page-scroll"><font color="white">Take a Tour</font></a> </div>
</header>
<!-- Portfolio Section -->
<div id="works-section">
  <div class="container"> <!-- Container -->
    <div class="section-title text-center center">
      <h2>Our Portfolio</h2>
      <hr>
      <div class="clearfix"></div>
      <p>Gallary of Govt. CPC Polytechnic,Mysuru</p>
    </div>
    <div class="categories">
      <ul class="cat">
        <li>
          <ol class="type">
            <li><a href="#" data-filter="*" class="active">All</a></li>
            <li><a href="#" data-filter=".web">Web Design</a></li>
            <li><a href="#" data-filter=".app">App Development</a></li>
            <li><a href="#" data-filter=".branding">Branding</a></li>
          </ol>
        </li>
      </ul>
      <div class="clearfix"></div>
    </div>
    <div class="row">
      <div class="portfolio-items">
        <div class="col-sm-6 col-md-3 col-lg-3 web">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/01.jpg" rel="prettyPhoto">
              <div class="hover-text">
                <h4>Project Title</h4>
                <small>Web Design</small>
                <div class="clearfix"></div>
              </div>
              <img src="img/portfolio/01.jpg" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 app">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/02.jpg" rel="prettyPhoto">
              <div class="hover-text">
                <h4>Project Title</h4>
                <small>App Development</small>
                <div class="clearfix"></div>
              </div>
              <img src="img/portfolio/02.jpg" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 web">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/03.jpg" rel="prettyPhoto">
              <div class="hover-text">
                <h4>Project Title</h4>
                <small>Web Design</small>
                <div class="clearfix"></div>
              </div>
              <img src="img/portfolio/03.jpg" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 web">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/04.jpg" rel="prettyPhoto">
              <div class="hover-text">
                <h4>Project Title</h4>
                <small>Web Design</small>
                <div class="clearfix"></div>
              </div>
              <img src="img/portfolio/04.jpg" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 app">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/05.jpg" rel="prettyPhoto">
              <div class="hover-text">
                <h4>Project Title</h4>
                <small>App Development</small>
                <div class="clearfix"></div>
              </div>
              <img src="img/portfolio/05.jpg" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 branding">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/06.jpg" rel="prettyPhoto">
              <div class="hover-text">
                <h4>Project Title</h4>
                <small>Branding</small>
                <div class="clearfix"></div>
              </div>
              <img src="img/portfolio/06.jpg" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 branding app">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/07.jpg" rel="prettyPhoto">
              <div class="hover-text">
                <h4>Project Title</h4>
                <small>App Development, Branding</small>
                <div class="clearfix"></div>
              </div>
              <img src="img/portfolio/07.jpg" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3 web">
          <div class="portfolio-item">
            <div class="hover-bg"> <a href="img/portfolio/08.jpg" rel="prettyPhoto">
              <div class="hover-text">
                <h4>Project Title</h4>
                <small>Web Design</small>
                <div class="clearfix"></div>
              </div>
              <img src="img/portfolio/08.jpg" class="img-responsive" alt="Project Title"> </a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- About Section -->
<div id="about-section">
  <div class="container">
    <div class="section-title text-center center">
      <h2>About Us</h2>
      <hr>
      <div class="clearfix"></div>
   
    </div>
    <div class="row">
      <div class="col-md-6"> <img src="img/about.jpg" class="img-responsive"> </div>
      <div class="col-md-6">
        <div class="about-text">
          <h3>ABOUT DAMS .</h3>
          <p>Digital Attendance Management System (DAMS) system deals with the maintenance of the student’s attendance details. It is generates the attendance of the student on basis of presence in class. It is maintained on the daily basis of their attendance. the staffs will be provided with the separate username & password to make the student’s status. 
The staffs handling the particular subjects responsible to make the attendance for all students. Only if the student present on that particular period, the attendance will be calculated. The students attendance reports based on monthly and consolidate will be generated.
</p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Achievements Section -->
<div id="achievements" class="section dark-bg">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-3">
        <div class="achievement-box"> <span class="count">283</span>
          <h4>Days</h4>
        </div>
      </div>
      <div class="col-md-3 col-sm-3">
        <div class="achievement-box"> <span class="count">09</span>
          <h4>Months</h4>
        </div>
      </div>
      <div class="col-md-3 col-sm-3">
        <div class="achievement-box"> <span class="count">04</span>
          <h4>Peoples</h4>
        </div>
      </div>
      <div class="col-md-3 col-sm-3">
        <div class="achievement-box"> <span class="count">24</span>
          <h4>Hours</h4>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Team Section -->
<div id="team-section" class="text-center">
  <div class="container">
    <div class="section-title center">
      <h2>Meet the Team</h2>
      <hr>
      <p>We are DAMS ....</p>
    </div>
    <div id="row">
      <div class="col-md-3 col-sm-6 team">
        <div class="thumbnail"> <img src="img/team/1.jpg" alt="..." class="img-circle team-img">
          <div class="caption">
            <h3>Chandan Kumar . M </h3>
            
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 team">
        <div class="thumbnail"> <img src="img/team/2.jpg" alt="..." class="img-circle team-img">
          <div class="caption">
            <h3>Dhanush B L</h3>
            
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 team">
        <div class="thumbnail"> <img src="img/team/3.jpg" alt="..." class="img-circle team-img">
          <div class="caption">
            <h3>Gajendra Singh N </h3>
           
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 team">
        <div class="thumbnail"> <img src="img/team/4.jpg" alt="..." class="img-circle team-img">
          <div class="caption">
            <h3>Mohammed Afzal A</h3>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- Contact Section -->
<div id="contact-section" class="text-center">
  <div class="container">
    <div class="section-title center">
      <h2>Contact Us</h2>
      <hr>
      <p>Contact us for More Information.</p>
    </div>
    <div class="col-md-8 col-md-offset-2">
      <div class="col-md-4"> <i class="fa fa-map-marker"></i>
  <p>Govt. CPC Polytechnic,<br>Ashoka Road <br> Mysuru .
    </p>
      </div>
      <div class="col-md-4"> <i class="fa fa-envelope"></i>
  <p>report-us@dams.cf</p>
      </div>
      <div class="col-md-4"> <i class="fa fa-phone"></i>
  <p> +91 8792253389</p>
      </div>
      <hr>
      <div class="clearfix"></div>
    </div>
    <div class="col-md-8 col-md-offset-2">
      <h3>Leave us a message</h3>
      <form name="sentMessage" id="contactForm" novalidate>
  <div class="row">
    <div class="col-md-6">
      <div class="form-group">
        <input type="text" id="name" class="form-control" placeholder="Name" required="required">
        <p class="help-block text-danger"></p>
      </div>
    </div>
    <div class="col-md-6">
      <div class="form-group">
        <input type="text" id="email-id" class="form-control" placeholder="Email" required="required">
        <p class="help-block text-danger"></p>
      </div>
    </div>
  </div>
  <div class="form-group">
    <textarea name="message" id="message" class="form-control" rows="4" placeholder="Message" required></textarea>
    <p class="help-block text-danger"></p>
  </div>
  <div id="success"></div>
  <button type="submit" class="btn btn-default">Send Message</button>


        <script src="https://code.jquery.com/jquery-2.2.4.js" integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI=" crossorigin="anonymous"></script>
        <script type="text/javascript" src="addons\Additional animate_css\Sweet Alert\sweet-alert\sweetalert2.js"></script>

      
      </form>
    </div>
  </div>
</div>

<div id="footer">
  <div class="container">
    <div class="fnav">
    <p>Copyright &copy; DAMS. Designed by a <a href="#team-section" class="page-scroll" rel="nofollow">DAMS Group</a></p>
    
    <!-- ============== Facebook button ==================== -->

  <iframe src="https://www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FDAMSGroupIN%2F&width=140&layout=button_count&action=like&size=large&show_faces=false&share=true&height=46&appId" width="140" height="46" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

    <!-- ============== Facebook button ==================== -->
    <br>
    <!-- ============== googleplus button ==================== -->


<!-- Place this code where you want the badge to render. -->
<a href="//plus.google.com/106755045469933925799?prsrc=3" rel="publisher" target="_top" style="text-decoration:none;display:inline-block;color:#333;text-align:center; font:13px/16px arial,sans-serif;white-space:nowrap;">
<span style="display:inline-block;font-weight:bold;vertical-align:top;margin-right:5px; margin-top:8px;"><font color="white">Dams</span><span style="display:inline-block;vertical-align:top;margin-right:15px; margin-top:8px;">on</span>
<img src="//ssl.gstatic.com/images/icons/gplus-32.png" alt="Google+" style="border:0;width:32px;height:32px;"/>
</a> &nbsp;

    <!-- ============== Google plus button ==================== -->
    
  <a href="https://www.facebook.com/DAMSGroupIN/"> <img src="https://www.reportography.com/wp-content/uploads/2016/11/facebook_icon.png" width=4% height=4%></a></font>

    </div>
  </div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script type="text/javascript" src="js/jquery.1.11.1.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script type="text/javascript" src="js/bootstrap.js"></script> 
<script type="text/javascript" src="js/SmoothScroll.js"></script> 
<script type="text/javascript" src="js/jquery.counterup.js"></script> 
<script type="text/javascript" src="js/waypoints.js"></script> 
<script type="text/javascript" src="js/jquery.prettyPhoto.js"></script> 
<script type="text/javascript" src="js/jquery.isotope.js"></script> 
<script type="text/javascript" src="js/jqBootstrapValidation.js"></script> 
<script type="text/javascript" src="js/contact_me.js"></script> 

<!-- Javascripts
    ================================================== --> 
<script type="text/javascript" src="js/main.js"></script>
<script type="text/javascript" src="addons/js/signup_validate.js"></script>


<!-- google captcha -->
 <script src='https://www.google.com/recaptcha/api.js'></script>

</body>
</html>
