<html>
<body  onresize="location.reload();">
</html>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
$pagetitle="Search Report";

include "includes/header.php"; 
include "connection2.php";

if(isset($_POST['search']))
{
$stdname=$_POST['stdname'];
$subj=$_POST['subject'];
$subj=preg_replace('/\s+/', '', $subj);

$con=new mysqli("localhost","id4172165_damsonline","damsonline","id4172165_dams");
$sql= $con->query("SELECT * FROM student_entry WHERE studentname='$stdname' ");
if($sql)
{
$result= $sql->fetch_assoc();
$stdid= $result['regno'];
} else { echo "Error :" .$conn->error;  }

$query= $conn->query("SELECT * FROM $subj WHERE stdname='$stdname' AND stdid='$stdid' ");
if(!$query)
{
    echo "Error :" .$conn->error; 
} else {
$result= $query->fetch_assoc();
$present= $result['present'];
$absent= $result['absent'];
}


} else {  echo "<br><div class='container'>
                    <div class='alert alert-danger alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4>&emsp;Warning!, Page is not Redirected from the source</h4> 
                    </div>
                    </div>
                "; }

?>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
   google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawAxisTickColors);

function drawAxisTickColors() {
      var data = google.visualization.arrayToDataTable([
        ['Student', 'Number of Days Present', 'Number of Days Absent' , 'Total Number of Days'],
        ['<?php echo $stdname; ?>',  <?php echo $present; ?> , <?php echo $absent; ?> , 31],
      
      ]);

      var options = {
          backgroundColor: 'transparent',
        title: 'Attendence Result of Student <?php echo $stdname; ?>',
        chartArea: {width: '50%'},
        hAxis: {
          title: 'Total Number of Days',
          minValue: 0,
          maxValue:30,
          textStyle: {
            bold: true,
            fontSize: 12,
            color: 'green'
          },
          titleTextStyle: {
            bold: true,
            fontSize: 18,
            color: 'green'
          }
        },
        vAxis: {
          title: 'Student',
          textStyle: {
            fontSize: 14,
            bold: true,
            color: '#848484'
          },
          titleTextStyle: {
            fontSize: 14,
            bold: true,
            color: '#848484'
          }
        }
      };
      var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    }
    
    
  </script>









<div class="container">
 <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Individual Report </span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                
                
              <div id="chart_div"></div>
            </div><!--row-->  
            </div><!--container-->    
            <script type="text/javascript" src="chart/js/jquery.min.js"></script>
		    <script type="text/javascript" src="chart/js/Chart.min.js"></script>
	    	<script type="text/javascript" src="chart/js/app.js"></script>
	    	
		
            <?php include "includes/footer.php"; ?>




