<?php
ob_start();
session_start();

             if(isset($_SESSION['name'])){
              $username=($_SESSION['email']);
              $userId=($_SESSION['name']);
            }
            else{
              die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");
            }

      ?>


<?php
 $pagetitle="Profile Page";
 include "includes/header.php"; 
 include "../connection.php";?>
 
 <?php
$email= $_SESSION['email'];
$sql = "SELECT name,email FROM users WHERE email='$email' ";
$result= $conn->query($sql);
if($result->num_rows>0)
{
    $result=$result->fetch_assoc();
    $email=$result['email'];
    $name=$result['name'];
}
?>
 
 <?php
 if(isset($_POST['name']))
 {
    $_SESSION['altername']=$email;
    header('Location:user-name.php');
 } else if(isset($_POST['email']))
 {
    $_SESSION['alteremail']=$email;
    header('Location:user-email.php');
 } else if(isset($_POST['password']))
 {
    $_SESSION['alterpass']=$email;
    header('Location:user-password.php');
 }
 
 ?>

 
<style>
    img[src="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]{
        display:none;
    }
</style>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.9/css/all.css" integrity="sha384-5SOiIsAziJl6AWe0HWRKTXlfcSHKmYV4RBF18PPJ173Kzn7jzMyFuTtk8JA7QQG1" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>



<div class="container">

        <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Edit Profile</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                            
                        </div>
                    </div>
                </div>
               
              
                    
      <div class="container">
        <div class="row">
          <div class="form-group">
          <form action="#" method="POST" role="form">
              <font size="5px">
            <br><p>User name&emsp;&emsp;: &emsp;&emsp;<?php echo $name;?> <center>
                <button type="submit" name="name" class="ui blue tiny button "><i class="fas fa-pencil-alt"></i> &nbsp;Change</button>
                </center></p>
          </form>
          <form action="user-email.php" method="POST" role="form">
              <br><p>E-mail address : &emsp;&emsp;<?php echo $email;?> <center>
                <button type="submit" name="email" class="ui blue tiny button "><i class="fas fa-pencil-alt"></i> &nbsp;Change</button>
            </center></p> 
          </form>
          <form action="user-password.php" method="POST" role="form">
               <br><p>Password &emsp;&emsp; : &emsp;&emsp;********(Encrypted & Secure) <center>
                <button type="submit"  name="password" class="ui blue tiny button "><i class="fas fa-pencil-alt"></i> &nbsp;Change</button>
                </center></p>
                <br><br>
                 </font>
          </form>
          </div>
          </div>
          </div>
 
               
          
          <a href="../logout.php"><button id="p" class="ui blue tiny button " style="font-size:20px"><i class="fas fa-power-off" ></i> &nbsp;Logout</button></a>
              
</div><!--container-->
<?php include "includes/footer.php"; ?>
