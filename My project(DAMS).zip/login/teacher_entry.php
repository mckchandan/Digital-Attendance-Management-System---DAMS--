<?php
session_start();

             if(isset($_SESSION['name'])){
              $username=($_SESSION['email']);
              $username=($_SESSION['name']);
            }
            else{
              die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");
            }
      ?>

<?php
 $pagetitle="Teachers Registration Page";
 include "includes/header.php"; 
 include "connection.php"; ?>
 <?php 
    if (isset($_POST['register'])) {
      
      $firstName = LTRIM(RTRIM(ucwords($_POST['name'])));
      $lastName = LTRIM(RTRIM(strtoupper($_POST['lname'])));
      $dob = $_POST['dob'];
      $gender = $_POST['gender'];
      $email = $_POST['email'];
      $phone= $_POST['phone'];
      $degree= $_POST['degree'];
      $salary= $_POST['salary'];
      $address= ucwords($_POST['address']);
      $kgid= strtoupper($_POST['kgid']);
      
      $teachername=$firstName.' '.$lastName;
      
      $sql1 = "SELECT * FROM teacher_entry WHERE email='".$email."' OR kgid='".$kgid."' OR phone='".$phone."' ";
      $result= $conn->query($sql1);
      if ($result->num_rows > 0)
      {
      echo "<br><div class='container'>
                    <div class='alert alert-info alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4 align='center'>&emsp;Sorry!, Teacher already Registered<br>Please Re-check your Email,Phone, or KGID</h4> 
                    </div>
                    </div>
                ";
      } else {

      $sql = "INSERT INTO teacher_entry(teachername,dob,gender,email,phone,degree,salary,address,kgid) VALUES ( '$teachername','$dob','$gender',LTRIM(RTRIM('$email')),LTRIM(RTRIM('$phone')),'$degree',LTRIM(RTRIM('$salary')),LTRIM(RTRIM('$address')),LTRIM(RTRIM('$kgid')) )";
    
      if($conn->query($sql) === TRUE)
{
    echo "<br><div class='container'>
                    <div class='alert alert-success alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4 align='center'>&emsp;Success!, New record created succesfully</h4> 
                    </div>
                    </div>
                ";
}
 else{
        echo "Error: " . $sql . "<br>" . $conn->error;
}      
    }
    }
     ?>  
<div class="container">

               <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Teachers Entry</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                </div>


<div class="form-container">

    <form action="#" method="post" role="form" >
    <div class="container">
    <div class="row">
    <div class="col-lg-3">
          <div class="form-group">
            <label for="name" > First Name (*)</label>
            <input type="text" class="form-control" required id="name" placeholder="First Name" autocomplete="off" name="name">
          </div>
    </div>
    <div class="col-lg-3">
          <div class="form-group">
            <label for="lname"> Last Name (*)</label>
            <input type="text" class="form-control" required id="lname" placeholder="Last Name" autocomplete="off"  name="lname">
          </div>
    </div>
    </div>
    </div>
    <div class="container">
    <div class="row">
    <div class="col-lg-3">
          <div class="form-group">
            <label for="dob"> Birthday </label>
            <input type="date" class="form-control" placeholder="DD-MM-YYYY" id="dob" name="dob" required>
          </div>
  </div>
  <div class="col-lg-3">

          <div class="form-group">
          <label for="gender">Gender</label>
           <select  class="form-control" required id="sex" name="gender" >
           <option>Male</option>
           <option>Female</option> 
           </select>
          </div>
  </div>
  </div>
  </div>

   <div class="container">
    <div class="row">
    <div class="col-lg-3">

          <div class="form-group">
            <label for="email" >Email address </label>
            <input type="email" class="form-control" required id="email" placeholder=" Email" autocomplete="off" name="email">
          </div>
   </div>
    <div class="col-lg-3">

          <div class="form-group">
            <label for="phone">Phone </label>
            <input type="text" class="form-control" id="phone" placeholder="Phone Number" autocomplete="off" name="phone" minlength="10" maxlength="10" required>
          </div>
    </div>
    </div>
    </div>

    <div class="container">
    <div class="row">
    <div class="col-lg-3">
           <div class="form-group">
          <label for="degree" >Degree (*)</label>
           <select  class="form-control" name="degree"  required id="degree" name="degree">
            <option></option>
           <option >BE</option>
           <option >M.Tech</option>
           <option >M.phil</option>
           <option >P.HD</option>
           <option >ITI</option>
           </select>
          </div>
    </div>
    <div class="col-lg-3">
          <div class="form-group">
            <label for="salary" > Salary </label>
            <input type="text" class="form-control" required id="salary" placeholder=" Enter salary" autocomplete="off" name="salary">
          </div>
    </div>
    </div>
    </div>

    <div class="container">
    <div class="row">
    <div class="col-lg-3">

          <div class="form-group">
            <label for="salary" > KGID (*) </label>
            <input type="text" class="form-control" required id="kgid" placeholder=" Enter Your KGID" autocomplete="off" name="kgid" minlength="10" maxlength="10">
          </div>
      </div>
    <div class="col-lg-3">
          <div class="form-group">
            <label for="address">Address</label>
            <textarea class="form-control" id="address" placeholder="Teacher address please" rows="3" name="address" required minlength=10 ></textarea>
          </div>
        </div>
    </div>
    </div>
          <div class="ui mini buttons col-sm-offset-3 col-sm-3">
          <button type="submit" class="ui mini positive button" name="register">Register</button>
          <div class="or"></div>
          <button type="reset" class="ui mini red button" name="back">Clear</button>
          </div>
      
       </form>
          </div><!--form-container-->
        </div> <!--container-->
   
<?php include "includes/footer.php"; ?>
