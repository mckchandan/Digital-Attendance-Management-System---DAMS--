<?php 
$conn=new mysqli("localhost","id4172165_damsonline","damsonline","id4172165_dams");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$email= $_SESSION['email'];
$status=0;
$teacher_msg="";
$sql= "SELECT kgid FROM teacher_entry WHERE email='".$email."' ";
                        $result= $conn->query($sql);
                        if($result->num_rows > 0)
                        {
                        $row= $result->fetch_assoc();
                        $status=1;
                        $userId= $row['kgid']; 
                        } else {
                            $teacher_msg= "<br><div class='container'>
                    <div class='alert alert-success alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4 align='center'>&emsp;Oops !, You are not in the list of Teacher's !<br>&emsp;Please Contact Admin to Register you as a Teacher</h4> 
                    </div>
                    </div>
                        "; 
                        }
                        

 ?>