<?php
session_start();

             if(isset($_SESSION['name'])){
              $username=($_SESSION['email']);
              $username=($_SESSION['name']);
            }
            else{
              die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");
            }
 $pagetitle="Student Page";
      ?>

<?php
 $pagetitle="Subjects Information";
 include "includes/header.php"; 
 include "connection.php";?>
 
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">


<div class="container">


              <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Subjects Details</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                </div>
<?php  echo $teacher_msg; ?>
               <p><a href="subject_entry.php"><button type="submit" name="insert" class="ui blue tiny button "  style="font-size:14px"><i class="fa fa-plus" ></i> &nbsp;Insert</button></a></p>
                <div class="table-responsive">
                 <table class="ui celled table table table-hover">
                  <thead>
                    <tr>          
                      <th>Subject Code</th>
                      <th>Subject Name</th>
                    
                      <th>Field</th>
                      <th>Semester</th>
                    </tr>
                  </thead>
      <tbody>
          <?php        
           
           if($status)
           {
            $sql = "SELECT * FROM subject_entry WHERE kgid='".$userId."' ";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
  
            echo '<tr>';        
            echo '<td>'. $row["subject_id"] . '</td>';
            echo '<td>'. $row['subject_name'] . '</td>';
            echo '<td>'. $row['field'] . '</td>';
            echo '<td>'. $row['semester'] . '</td>';
            }
            } else { echo "<br><div class='container'>
                    <div class='alert alert-success alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4 align='center'>&emsp;Oops !, No Subject's are Assigned you</h4> 
                    </div>
                    </div>
                "; }
            } 
           ?>
      </tbody>     
             </table>



</div> <!--table-responsive-->
</div><!--container-->
<?php include "includes/footer.php"; ?>
