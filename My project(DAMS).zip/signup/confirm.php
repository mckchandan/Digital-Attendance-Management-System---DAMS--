<style type="text/css">
		#mydiv{
			    width: 100%;
    height: 100%;
    position: absolute;
    background: #eee;
    text-align: center;
    font-family: calisto mt;
		}
	</style>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<?php

ob_start();

	if (!isset($_GET['email']) || !isset($_GET['token'])) {
		redirect();
	} else {
		$con = new mysqli('localhost', 'id4172165_damsonline', 'damsonline', 'id4172165_dams');

		$email = $con->real_escape_string($_GET['email']);
		$token = $con->real_escape_string($_GET['token']);

		$sql = $con->query("SELECT id FROM users WHERE email='".$email."' AND token='$token' AND isEmailConfirmed=0");

		if ($sql->num_rows > 0) {
			$con->query("UPDATE users SET isEmailConfirmed=1, token='' WHERE email='$email'");
			echo '<div id="mydiv">
	              <br>
	               <h1>Congratulations!</h1>
	               <h4> Your Email Verified Successfully. </h4> 
	               <br>
	               <p><a href="http://dams.cf/login"><button class="w3-button w3-black w3-round-xxlarge"><i class="fas fa-thumbs-up fa-2x" ></i>&emsp;<font size="6px;"><strong>Continue</strong></font></button></a></p>
	               </div>';
		} else{
		    	echo '<div id="mydiv">
	              <br>
	               <h1>Oops!,</h1>
	               <h4> Your Email Already Been Verified , Please Click the Continue Button to Login. </h4> 
	               <br>
	               <p><a href="http://dams.cf/login"><button class="w3-button w3-black w3-round-xxlarge"><i class="fas fa-thumbs-up fa-2x" ></i>&emsp;<font size="6px;"><strong>Continue</strong></font></button></a></p>
	               </div>';
		}
	}
?>