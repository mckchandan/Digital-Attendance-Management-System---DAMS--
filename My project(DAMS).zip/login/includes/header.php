
<!DOCTYPE html>
<html lang="en">


    <head>         
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $pagetitle; ?></title>
        
        <link rel="shortcut icon" href="../img/favicon.png" type="image/x-icon">
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css'>
        <link href="css/semantic.min.css" rel="stylesheet">
        <link href="css/templatemo_style.css"  rel='stylesheet' type='text/css'>
        <link href="css/mystyle.css"  rel='stylesheet' type='text/css'> 
         <style>
           .override:hover{
               background:black !important;
               border-radius:30px;
           }
           img[src="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]{
        display:none;
            }
        </style>
        <!-- ===== Page Loader ====== -->
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
        <script type="text/javascript">
        $(window).load(function() {
        $(".loader").fadeOut("slow");
        });
        </script> 
        
        <style>
        .loader {
            position: fixed;
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background: url('https://i.pinimg.com/originals/d1/2c/ae/d12cae398bdddd5d6daee9ec6c491333.gif') 50% 50% no-repeat rgb(249,249,249);
            
        }
        </style>
        
        <!-- ===== End of Loader ======= -->

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

    </head>   
    <body style="background-color: #f6f6f6;">
        <div class="loader"></div>
        <div class="templatemo-top-menu">
            <div class="container">
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                </button>
                                <a href="home.php"style="max-height:40px; max-width: 40px;" class="navbar-brand"><img src="image/favicon.png" alt="DAMS Group" title=" HOME" /></a>
                        </div>
                        <div class="navbar-collapse collapse" id="templatemo-nav-bar" class="external-link">
                            <ul class="nav navbar-nav navbar-right" style="margin-top: 40px;"  role="menu" aria-labelledby="dropdownMenu" aria-expanded="false">
                                <li><a href="home.php" class="external-link">Home</a></li>
                                <li><a href="student.php" class="external-link">Students</a></li>
                                <li><a href="teacher.php" class="external-link">Teachers</a></li>
                                <li><a href="subject.php" class="external-link">Subjects</a></li>
                                 <li><a href="SearchAttendReport.php" class="external-link">Monthly Report</a></li>
                            <!-- <li><a href="AttendenceReport.php" class="external-link">Overall Report</a></li> -->
                                  <li><a href="AttendenceForm.php" class="external-link">Do Attendance</a></li>

                        <!--    <li><a href="logout.php" class="external-link" >Log Out</a></li> --->
                                <li title="<?php echo "Dams Account: ".$_SESSION['name']. "\n(" .$_SESSION['email']. ")" ; ?>">
                                    <a href="user/profile.php" class="external-link override" >
                                        <i class="fas fa-user fa-3x"></i>
                                    </a>
                                </li>
                             </ul>
                        </div><!--/.nav-collapse -->
                    </div><!--/.container-fluid -->
                </div><!--/.navbar -->
            </div> <!-- /container -->
        </div>