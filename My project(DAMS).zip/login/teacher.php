<?php

session_start();



             if(isset($_SESSION['name'])){

              $username=($_SESSION['email']);

              $userId=($_SESSION['name']);

            }

            else{

              die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");

            }

 $pagetitle="Student Page";

      ?>



<?php

 $pagetitle="Teacher Records";

 include "includes/header.php";
 include "connection.php"; ?>



<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

<div class="container">

	<?php 

		if(isset($_GET['teacher_id'])){

       $t_id = $_GET['teacher_id'];


        $sql="DELETE FROM teacher_entry WHERE kgid='".$t_id."' ";

        if ($conn->query($sql) === TRUE) {
            echo "<h1><br>Record Deleted Successfully</h1>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

               } ?>



              <div class="row">

                    <div class="templatemo-line-header" style="margin-top: 0px;" >

                        <div class="text-center">

                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Teacher Record</span>

                            <hr class="team_hr team_hr_right hr_gray" />

                        </div>

                    </div>

                </div>

               <p><a href="teacher_entry.php"><button type="submit" name="insert" class="ui blue tiny button "  style="font-size:14px"><i class="fa fa-plus" ></i> &nbsp;Insert</button></a></p>

                <div class="table-responsive">

                 <table class="ui celled table table table-hover">

                  <thead>

                    <tr>

                  

                      <th>Teacher Name</th>

                      <th>DOB</th>

                      <th>Gender</th>

                      <th>Email</th>

                      <th>Phone</th>

                      <th>Degree</th>

                      <th>Salary</th>

                      <th>Address</th>

                      <th>Action</th>

                    </tr>

                  </thead>

     <tbody>

          <?php        

            $sql = "SELECT * FROM teacher_entry ORDER BY  kgid LIMIT 10";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
    
            while($row = $result->fetch_assoc()) {
            

            /* foreach ($veiw as $post) {

            $teacher_id = $post['teacher_id']; */

  

          echo '<tr>';



                     

            echo '<td>'. $row['teachername'] . '</td>';

            echo '<td>'. $row['dob'] . '</td>';

            echo '<td>'. $row['gender'] . '</td>';

            echo '<td>'. $row['email'] . '</td>';

            echo '<td>'. $row['phone'] . '</td>';

            echo '<td>'. $row['degree'] . '</td>';

            echo '<td>'. $row['salary'] . '</td>';

            echo '<td>'. $row['address'] . '</td>';

            

            echo '<td width=250>';

            echo "<div class='ui mini buttons'>";

            echo '<a class="ui mini positive button" href="teacher_update.php?teacher_id='.$row['kgid'].'"> <i class="fas fa-pencil-alt"></i>&emsp;Update</a>';

            echo "<div class='or'></div>";    

            echo '<a class="ui mini red button" href="teacher.php?teacher_id='.$row['kgid'].'"><i class="fas fa-trash"> </i>&emsp;Delete</a>';

            echo "</div>";

            echo '</td>';    

           echo '</tr>';  

            }
          }

           ?>

      </tbody>     

            </table>

            </div><!--table-responsive-->

            </div><!--row-->   

           </div><!--container-->	  

<?php include "includes/footer.php"; ?>