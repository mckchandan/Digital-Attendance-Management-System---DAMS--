<?php
ob_start();
error_reporting(E_ALL ^ E_DEPRECATED);
include("connection2.php");
    
$stdname=$_POST['studentname'];
$subj=$_POST['subjname'];
$subj=preg_replace('/\s+/', '', $subj);
$atten=$_POST['attendence'];
$date = date('Y-m-d H:i:s');

if(isset($_POST['save']))
{
$sql = "CREATE TABLE IF NOT EXISTS $subj(
          stdname VARCHAR(200),
          stdid VARCHAR(200) NOT NULL,
          present INT NULL,
          absent INT NULL,
          timestamp DATETIME
        )";
$result= $conn->query($sql);
if(!$result)
{
      echo "Error: ". $conn->error;
    
}



$con=new mysqli("localhost","id4172165_damsonline","damsonline","id4172165_dams");
$sql= $con->query("SELECT * FROM student_entry WHERE studentname='$stdname' ");
$result= $sql->fetch_assoc();
$stdid= $result['regno'];





$att= $conn->query("SELECT present,absent FROM $subj WHERE stdid='$stdid'");
$row= $att->fetch_assoc();
$pre= $row['present'];
$abs= $row['absent'];

if($atten==1)
{
    $pre= $pre + 1;
} else { 
    $abs= $abs + 1;
}





$verify= $conn->query("SELECT * FROM $subj WHERE stdid='$stdid' AND stdname='$stdname' ");
$query="";
 $pre_update="";
if($verify->num_rows > 0)
{ 
    $pre_update= $conn->query("UPDATE $subj SET present='$pre' , absent='$abs' WHERE stdid='$stdid' ");

} else {
    
$query=$conn->query("INSERT INTO $subj (stdname,stdid,present,absent,timestamp)VALUES('$stdname','$stdid','$pre','$abs','$date')");

} // verify 
if($query==true || $pre_update==true)
{
  echo "<p style='text-align:center;'><img src='image/success.png'></p>";
  echo "<center><h3>** Page will Redirect after 3s **</h3></center>";
  header("Refresh: 2; url=AttendenceForm.php");
  } else {    
       echo $subj."".$date;
   echo "<br>Error: " . $conn->error;
  	echo "<p style='text-align:center;'><img src='http://errors.co.in/error.jpeg'></p>";
  	echo "<center><h3>** Page will Redirect after 3s **</h3></center>";
  	header("Refresh: 2; url=AttendenceForm.php");
  }
} //isset
else { echo "<center><h3>** The Page is not Redirected from the actual site **</center></h3>";  }

?>

