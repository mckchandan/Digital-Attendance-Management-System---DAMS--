<?php
session_start();

             if(isset($_SESSION['name'])){
              $username=($_SESSION['email']);
              $userId=($_SESSION['name']);
            }
            else{
              header("Location:login.php");
            }

 $pagetitle="Home Page";
 include "includes/header.php";
      include "includes/slider.php";
      ?>




<div class="loader"></div>
        <div class="templatemo-welcome" id="templatemo-welcome">
            <div class="container">
                <div class="templatemo-slogan text-center">
                    <span class="txt_darkgrey">Welcome to </span><span class="txt_orange">Home Page</span>
                    <p class="txt_slogan">
                </div>	
            </div>
        </div>   
        

    <div id="templatemo-blog">
            <div class="container">
                <div class="row">
                 <?php include "includes/sidebar.php";?>
                <div class="blog_box">
                    <div class="col-sm-5 col-md-6 blog_post">
                        <ul class="list-inline">
                        <li>    
                        <div class="clearfix"> </div>
                        <p class="blog_text">
                            Government CPC Polytechnic, popularly known as CPC Polytechnic is a premier technical institute of Karnataka state situated in the garden city of Mysore. It was established in the year 1954 under the erstwhile Mysore State Government. The sprawling land of 5.09 acres and spacious building of nearly 2,15,267 sq.ft was donated by Sri C. Perumal Chettiar, a philanthropist, to the then Government of Mysore
                            Government CPC Polytechnic is an AICTE approved institution run by Government of Karnataka and coming under the purview of Directorate of Technical Education. The institute is rendering yeomen service to the citizens of Mysore and surrounding areas by offering three year diploma program in various engineering and non engineering courses. The training is rendered by well qualified dedicated staff with supportive infrastructure.</p>
                            </li>
                        </ul>
                    </div> <!-- /.blog_post 1 --> 
                </div>
              </div>
           </div>
    </div>
<?php include "includes/footer.php"; ?>