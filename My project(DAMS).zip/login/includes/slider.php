 <style type="text/css">
     h1{
        position:relative;
        top:-70px;
        color:#fff;
     }
     .p{
        position:relative;
        top:-70px;
        color:#000;
     }
 </style>
 <div>
            <!-- Carousel -->
            <div id="templatemo-carousel" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#templatemo-carousel" data-slide-to="0" class="active"></li>
                    <li data-target="#templatemo-carousel" data-slide-to="1"></li>
                    <li data-target="#templatemo-carousel" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="item active">
                        <div class="container">
                            <div class="carousel-caption">
                                <h1>WELCOME TO DAMS</h1>
                                <h1>A Step towards Digital with DAMS</h1>
                                <p class="p">Digital Attendance Management System..... </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="item">
                        <div class="container">
                                <div class="carousel-caption">
                                
                                    
                                    	<h1>ABOUT </h1>
                                        <p class="p">Digital Attendance Management System is here to help you to Save your<br> TIME and WORKLOAD .....</p>
                                    
                                </div>
                        </div>
                    </div>
                        <div class="item">
                            <div class="container">
                                <div class="carousel-caption">
                                	<h1>HOW IT SAVES TIME</h1>
                                    <p class="p">By Marking the Attendance in Digital Way..... </p>
                                    <p class="p"><a class="btn btn-lg btn-orange" href="#" role="button">Take a Tour</a></p>
                                </div>
                            </div>
                        </div>
                </div>
                <a class="left carousel-control" href="#templatemo-carousel" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
                <a class="right carousel-control" href="#templatemo-carousel" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
            </div><!-- /#templatemo-carousel -->
        </div>