       <div class="templatemo-footer">
            <div class="container">
                <div class="row" style="margin-top:20px;">
                        <div class="col-md-3">
                        </div>
                        <div class="col-md-7 footer_txt" >
                                <span>  
                        <div class="footer_bottom_content">
                    
                            <p>Copyright&copy; <?php echo date('Y'); ?> Digital Attendance Management System (DAMS)</p>
                       
                             Supervisor: Mr. Manjappa Nayak <br>
                             Developer: <a href="https://www.facebook.com/sahar0816" target="new">DAMS Group</a>
                        </div></span>
            
                        </div>
                 </div><!-- /.row -->
            </div><!-- /.container -->
        </div>


        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js"  type="text/javascript"></script>
        <script src="js/templatemo_script.js"  type="text/javascript"></script>
        <script src="js/myscript.js"  type="text/javascript"></script>


    </body>
</html>


