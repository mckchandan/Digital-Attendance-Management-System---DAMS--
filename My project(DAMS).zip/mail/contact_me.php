
<?php
// Check for empty fields
if(empty($_POST['name'])  		||
   empty($_POST['email']) 		||
   empty($_POST['message']))
   {
	echo "<h1>No arguments Provided!</h1>";
	return false;
   }
	
$name = $_POST['name'];
$email_address = $_POST['email'];
$message = $_POST['message'];
	

require 'phpmailer/PHPMailerAutoload.php';

 
// creates object
$mail = new PHPMailer(); 



$mail->IsSMTP(); 
$mail->isHTML(true);
$mail->SMTPDebug = 0; 
$mail->SMTPAuth = true; 
$mail->SMTPSecure = "ssl"; 
$mail->Host = "smtp.gmail.com"; 
$mail->Port = '465'; 
$mail->AddAddress($email_address);
$mail->Username ="dams.cf@gmail.com"; 
$mail->Password ="zldarbjsnqgwudhj"; 
$mail->SetFrom("report-us@gmail.com","Dams Group");
$mail->AddReplyTo("report-us@gmail.com","Dams Group");
$mail->Subject = "Thank You";
$mail->Body = "
    <img src='http://math4me.ca/wp-content/uploads/2015/04/thank-you-feedback-text.png'>
    <font face='Helvetica'><p><br><br>
                    Regards :<br>
                    <b>The DAMS Group</b><br>
                    www.dams.cf<br><br>
                    </p>
                    <a href='https://www.facebook.com/DAMSGroupIN/'><img src='https://cbdspain.com/wp-content/uploads/2017/12/099085-glossy-black-3d-button-icon-social-media-logos-facebook-logo-square.png' width='9%' height='9%' alt='facebook'></a>
                    </font>
    
    ";
$mail->AltBody = "hlo";
if($mail->Send())
echo "<h1>Hi, Your mail successfully sent to</h1>";
else
echo "".$mail->ErrorInfo;
?>

