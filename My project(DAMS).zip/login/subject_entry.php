<?php
session_start();

             if(isset($_SESSION['name'])){
              $username=($_SESSION['email']);
              $username=($_SESSION['name']);
            }
            else{
              die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");
            }
      ?>

<?php
 $pagetitle="Entering Subjects Detail In This Page ";
 include "includes/header.php"; 
 include "connection.php"; ?>

 <?php 
    if (isset($_POST['save'])) {
    
      $subName = $_POST['subject'];
      $teacher= $_POST['teacher'];
      $field = $_POST['field'];
      $semester= $_POST['semester'];
      $sub_id = $_POST['subjid'];
      
    $sql1 = "SELECT kgid FROM teacher_entry WHERE teachername='".$teacher."' ";
    $result= $conn->query($sql1);
    $result= $result->fetch_assoc();
    $kgid= $result['kgid'];

    $verify= $conn->query("SELECT * FROM subject_entry WHERE subject_id='$sub_id' ");
    if($verify->num_rows>0)
    {
        echo "<br><div class='container'>
                    <div class='alert alert-info alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4 align='center'>&emsp;<b>Info!</b>, Subject Already Registered !</h4> 
                    </div>
                    </div>
                ";
    } else {
    
    $sql = "INSERT INTO subject_entry(subject_name,teacher_name,field,semester,subject_id,kgid) VALUES ('$subName','$teacher','$field','$semester','$sub_id','$kgid' )";
    
      if($conn->query($sql) === TRUE)
        {
      echo "<br><div class='container'>
                    <div class='alert alert-success alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4 align='center'>&emsp;Success!, New record created succesfully</h4> 
                    </div>
                    </div>
                ";
        }
        else{
        echo "Error: " . $sql . "<br>" . $conn->error;
        }      
    }
}
     ?>  


 <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
    
<div class="container">

               <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Subject's Entry</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                </div>
                

<div class="form-container">

    <form action="#" method="post" role="form">
    <div class="container">
    <div class="row">
          <div class="col-lg-4">

          <div class="form-group">
            <label for="field" >Program</label>
           <select  class="form-control" required id="field" name="field">
           <option></option>
           <option >Computer Science & Engg.</option>
           </select>
          </div>
          </div>
    
          <div class="col-lg-3">

          <div class="form-group">
           <label for="semester" >Semester </label>
           <select  class="form-control" required id="semester" name="semester">
            <option></option>
           <option>2nd</option>
           <option>4th</option>
           <option>6th</option> 
           </select>
          </div>
          </div>

         </div><!--col-row-->
          </div><!--col-container-->
           <div class="container">
          <div class="row">
          <div class="col-lg-4">

          <div class="form-group">
            <label for="subject" >Course Name </label>
           <select  class="form-control" required id="subject" name="subject" >
           <option></option>
           </select>
          </div>
          </div>
        
        
      
         <div class="col-lg-3">
          <div class="form-group">
          <label for="teacher" >Teacher Name</label>
           <select  class="form-control" required id="teacher" name="teacher">
            <!-- <option></option>
           <option >Manjappa Nayak</option>
           <option >Shekara K N</option>
           <option >Latha P H</option>
           <option >Madhu N Y</option>
           <option >Anusuya D</option>  -->
           <?php
        $sql = "SELECT * FROM teacher_entry";
        $result = $conn->query($sql);

            if ($result->num_rows > 0) {

            while($row = $result->fetch_assoc()) {

           echo '<option>' .$row['teachername']. '</option>';
           
            }
          }
           ?>
           </select>
          </div>
          </div>
      </div>
      </div>


      <div class="container">
          <div class="row">
              
          <div class="col-lg-4">
          <div class="form-group">
            <label for="subjid" >Course Code </label>
           <select  class="form-control" id="subjid" name="subjid" required>
           <option></option>
           </select>
          </div>
          </div>
        </div>
      </div>

          <div class="ui mini buttons col-sm-offset-3 col-sm-3">
          <button type="submit" class="ui mini positive button" name="save">Register</button>
          <div class="or"></div>
          <button type="reset" class="ui mini red button" name="back">Clear</button>
          </div>
      
  </form>
  
  
 <!-- ================= subject validate ================ -->
   <script type="text/javascript" src="js/subject.js"></script>
 <!-- ================= subject validate ================ -->   
   
 </div><!--form-container-->
 </div> <!--container-->
   
<?php include "includes/footer.php"; ?>
