<?php
session_start();

             if(isset($_SESSION['name'])){
              $username=($_SESSION['email']);
              $username=($_SESSION['name']);
            }
            else{
              die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");
            }
      ?>
<?php 
   $pagetitle="Update Student's Record";
  include "includes/header.php";
  include "connection.php" ?>



<?php 

      if(isset($_GET["std_roll_no"]))
        {
        $id = $_GET["std_roll_no"];
        }

    if (isset($_POST['update']))
    {
      $studentName = ucwords($_POST['name']);
      $dob = $_POST['dob'];      
      $email = $_POST['email'];
      $phone= $_POST['phone'];
      $add= ucwords($_POST['add']);      
      $program= $_POST['program'];
      $semester= $_POST['semester'];   
      $rollno= $_GET ['std_roll_no'];   


      $sql = "UPDATE student_entry SET studentname=LTRIM(RTRIM('".$studentName."')),dob='".$dob."',email=LTRIM(RTRIM('".$email."')),phone='".$phone."',address=LTRIM(RTRIM('".$add."')),program='".$program."',semester='".$semester."' WHERE regno='".$rollno."'";

      if ($conn->query($sql) === TRUE) {
         echo "<br><div class='container'>
                    <div class='alert alert-success alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4 align='center'>&emsp;Success!, Student Information Updated Successfully</h4> 
                    </div>
                    </div>
                ";
      } else {
          echo "Error: " . $sql . "<br>" . $conn->error;
      }
      }
      
     ?>
     

     

<div class="container">


                <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Updating Student</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                </div>
                


<div class="form-container">

    <form method="post" role="form" action="#">
       <div class="container">
           <div class="row">
           <div class="col-lg-4">
          <?php 
        
        
            $sql = "SELECT  * FROM  student_entry WHERE regno='".$id."' ";
            $result = $conn->query($sql);
      
          if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc())
          {
            
              
            
             ?>
          <div class="form-group">
            <label for="name"> Student Name(*) </label>
            <input type="text" name="name" class="form-control"  value="<?php echo $row['studentname']; ?>" required id="name" placeholder="student Name" autocomplete="off">
          </div>
          </div>
           
           <div class="col-lg-4">
          <div class="form-group">
            <label for="dob"> Date Of Birth </label>
            <input type="date" name="dob" class="form-control" value="<?php echo $row['dob']; ?>" id="dob" >
          </div>
          </div>
        </div>
        </div> <!-- col-container-->
       
        <div class="container">
           <div class="row">

        <div class="col-lg-4">
          <div class="form-group">
          <label for="gender">Gender(*)</label>          
           <input type="text" class="form-control" id="session" placeholder="session" name="session"  value="<?php echo $row['gender']; ?>" disabled="TRUE">
          </div>
        </div>
          <!-- </div> -->
          <!-- <div class="col-lg-6 push-right">  -->
        <div class="col-lg-4">
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo $row['email']; ?>" required id="email" placeholder=" Email" autocomplete="off">
          </div>
       </div>
       </div>
       </div><!-- col-container-->

      <div class="container">
       <div class="row">
       <div class="col-lg-4">
        <div class="form-group">
            <label for="phone">Phone </label>
            <input type="text" name="phone" class="form-control" value="<?php echo $row['phone']; ?>" id="phone" placeholder="Phone Number" autocomplete="off">
          </div>
       </div>
       <div class="col-lg-4">
          <div class="form-group">
            <label for="add">Address</label>
            <textarea name="add" class="form-control"  id="add" placeholder="Your address please" rows="3" autocomplete="off"><?php echo $row['address']; ?></textarea>
          </div>
       </div>
       </div>
     </div><!-- col-container-->
      <div class="container">
       <div class="row">
       <div class="col-lg-4">
      <div class="form-group">
            <label for="session" >Register Number</label>
            <input type="text" class="form-control" id="session" placeholder="session" name="session"  value="<?php echo $row['regno']; ?>" disabled="TRUE">
        </div>
        </div>
          <div class="col-lg-4">
          <div class="form-group">
          <label for="program"  class="col-sm-2 control-label">Program</label>
           <select  class="form-control" name="program"  required id="program" name="program"  >
           <option ></option>
           <option >Computer Science & Engg</option>
           <option >Electrical and Communication Engg</option>
           <option >Electrical and Electronics Engg</option>
           <option >Automobile Engg</option>
           <option >Civil Engg</option>
           <option >Commecrical Practice & Engg</option>
           <option >Mechanical Engg</option>
           </select>
          </div>  
          </div>
        </div>
          </div>

          <div class="col-lg-4">
          <div class="form-group">
          <label for="semester"  class="col-sm-2 control-label">Semester</label>
           <select  class="form-control" name="semester"  required id="semester"  value="<?php echo $row['semester']; ?>"  >
           <!-- <option selected disabled hidden style='display: none'>6th</option> -->
           <option></option>
           <option>1st</option>
           <option>2nd</option>
           <option>3rd</option> 
           <option>4th</option>
           <option>5th</option>
           <option>6th</option>        
           </select>
          </div>  
          </div>
          <div "form-actions"> <br><br>
          <div class="ui mini buttons col-sm-offset-3 col-sm-3">
          <button type="submit" class="ui mini positive button" name="update">Update</button>
          <div class="or"></div>
          <a href="student.php" type="submit" class="ui mini button" name="back">Back</a>
          </div>
          </div>
       </form>
   <?php } }  ?>
          </div>
     </div><!--container-->	 
<?php include "includes/footer.php"; ?>