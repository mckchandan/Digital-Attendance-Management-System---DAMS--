<?php
session_start();

             if(isset($_SESSION['name'])){
              $username=($_SESSION['email']);
              $userId=($_SESSION['name']);
            }
            else{
              die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");
            }
 $pagetitle="Student Page";
      ?>

  <?php
  $pagetitle="student data";
  // include "includes/header2.php";
  include "includes/header.php";
  include "connection.php"; ?>
  
  
<div class="container">
<?php
          if (isset($_GET['std_roll_no'])) {
            $id = $_GET['std_roll_no'];
            $delete="DELETE FROM student_entry WHERE regno='".$id."' ";
              if($conn->query($delete))
              {
              echo "<br><h1>Record has been Deleted Successfully</h1>";
            }
          }
?>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">


              <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Students Records</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                </div>
                <p><a href="student_entry.php"><button type="submit" name="insert" class="ui blue tiny button "  style="font-size:14px"><i class="fa fa-plus" ></i> &nbsp;Insert</button></a></p>
                <div class="table-responsive">
                 <table class="ui celled table table table-hover">
                  <thead>
                    <tr>
                     <!--  <th>Std Id</th> -->
                      <th>Student Name</th>
                      <th>DOB</th>
                      <th>Gender</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Address</th>
                      <th>Reg No</th>
                      <th>Program</th>
                      <th>Semester</th>
                      <th>Action</th>
                    </tr>
                  </thead>
     <tbody>
          <?php        
            $sql = "SELECT  * FROM  student_entry LIMIT 8";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {

          echo '<tr>';

            // echo '<td>'. $post['student_id'] . '</td>';          
            echo '<td>'. $row["studentname"] . '</td>';
            echo '<td>'. $row['dob'] . '</td>';
            echo '<td>'. $row['gender'] . '</td>';
            echo '<td>'. $row['email'] . '</td>';
            echo '<td>'. $row['phone'] . '</td>';
            echo '<td>'. $row['address'] . '</td>';
            echo '<td>'. $row['regno'] . '</td>';
            echo '<td>'. $row['program'] . '</td>';
            echo '<td>'. $row['semester'] . '</td>';
            
            echo '<td width=250>';
            echo "<div class='ui mini buttons'>";
            echo '<a class="ui mini positive button" href="student_update.php?std_roll_no='.$row['regno'].'"> <i class="fas fa-pencil-alt"></i>&emsp;Update</a>';
            echo "<div class='or'></div>";    
            echo '<a class="ui mini red button" href="student.php?std_roll_no='.$row['regno'].'"><i class="fas fa-trash"> </i>&emsp;Delete</a>';
            echo "</div>";
            echo '</td>';    
           echo '</tr>';  
            }
}
           ?>
      </tbody>     
            </table>
            </div><!--table-responsive-->   
           </div><!--container-->
<?php include "includes/footer.php"; ?>