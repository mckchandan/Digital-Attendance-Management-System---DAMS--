<?php
session_start();

             if(isset($_SESSION['name'])){
              $username=($_SESSION['email']);
              $username=($_SESSION['name']);
            }
            else{
              die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");
            }
      ?>

  <?php 
   $pagetitle="Students Registration";
  include "includes/header.php";
  include "connection.php"; 

     if (isset($_POST['register'])) {

      $studentName = LTRIM(RTRIM(ucwords($_POST['name'])));
      $dob = $_POST['dob'];
      $gender = ucfirst($_POST['gender']);
      $email = LTRIM(RTRIM(strtolower($_POST['email'])));
      $phone= LTRIM(RTRIM(ucwords($_POST['phone'])));
      $add= LTRIM(RTRIM(ucwords($_POST['add'])));
      $rollno = LTRIM(RTRIM(strtoupper($_POST['session'])));
      $program= $_POST['program'];
      $semester= $_POST['semester'];
      $fathername= LTRIM(RTRIM(ucwords($_POST['fname'])));
      $mothername= LTRIM(RTRIM(ucwords($_POST['mname'])));
      $religion= $_POST['religion'];
      $category= $_POST['category'];
        
        $sql="SELECT * FROM student_entry WHERE regno='".$rollno."'";
        $result = $conn->query($sql);
    //check the regno already exists or not.
        if ($result->num_rows > 0) {
            echo "<br><div class='container'>
                    <div class='alert alert-info alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4 align='center'>&emsp;Info!, Student already Registered</h4> 
                    </div>
                    </div>
                ";
        }
        else{
          
      $sql = "INSERT INTO student_entry(studentname,dob,gender,email,phone,address,regno,program,semester,father,mother,religion,category) VALUES ('$studentName','$dob','$gender','$email','$phone','$add','$rollno','$program','$semester','$fathername','$mothername','$religion','$category')";
      if($conn->query($sql) === TRUE)
{
echo "<br><div class='container'>
                    <div class='alert alert-success alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4 align='center'>&emsp;Success!, New record created succesfully</h4> 
                    </div>
                    </div>
                ";  }
 else{
         echo "Error: " . $sql . "<br>" . $conn->error;
}      
    } 
         
    }
     ?>  



</style>

<div class="container">
             <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Students Entry</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                </div>
          

<div class="form-container">
    <form action="#" method="post" role="form">

        <div class="container">
          <div class="row">
          <div class="col-lg-4">
          <div class="form-group">
            <label for="name" > Student Name(*) </label>
            <input type="text" class="form-control" required id="name" placeholder="student name"  name="name" autocomplete="off">
          </div>
          </div>
          <div class="col-lg-4">
          <div class="form-group">
            <label for="dob"> Date Of Birth </label>
            <input type="date" placeholder="DD-MM-YYYY" class="form-control" id="dob" name="dob" required>
          </div>
          </div>
         </div>
        </div>  <!-- col-container-->
        
 
        
        
        <div class="container">
          <div class="row">
          <div class="col-lg-4">
          <div class="form-group">
            <label for="name" > Father Name(*) </label>
            <input type="text" class="form-control" required id="fname" placeholder="Father name"  name="fname" autocomplete="off">
          </div>
          </div>
          <div class="col-lg-4">
          <div class="form-group">
            <label for="dob"> Mother Name(*) </label>
            <input type="text" placeholder="Mother Name" class="form-control" id="mname" name="mname" autocomplete="off" required>
          </div>
          </div>
         </div>
        </div>  <!-- col-container-->
        
        
        
        <div class="container">
          <div class="row">
          <div class="col-lg-4">
          <div class="form-group">
            <label for="name" > Religion(*) </label>
            <select  class="form-control" required name="religion" id="religion">    
           <option></option>
           <option>Hindu</option>
           <option>Muslim</option>
           <option>Christian</option>
           </select>
          </div>
          </div>
          <div class="col-lg-4">
          <div class="form-group">
            <label for="dob"> Category(*) </label>
            <select  class="form-control" required id="category" name="category">    
           <option></option>
           <option>CAT-1</option>
           <option>1A</option>
           <option>1B</option>
           <option>2A</option>
           <option>2B</option>
           <option>3A</option>
           <option>3B</option>
           <option>SC</option>
           <option>ST</option>
           </select>
          </div>
          </div>
         </div>
        </div>  <!-- col-container-->
        
        

         <div class="container">
          <div class="row">
           <div class="col-lg-4">

          <div class="form-group">
          <label for="gender"  >Gender(*)</label>
           <select  class="form-control"   required id="sex" name="gender">           
           <option>Male</option>
           <option>Female</option> 
           </select>
          </div>
          </div>
          <div class="col-lg-4">

          <div class="form-group">
            <label for="email"  >Email address </label>
            <input type="email" class="form-control" required id="email" placeholder=" Email" name="email" autocomplete="off">
          </div>
          </div>
           </div>
          </div><!-- col-container-->

       <div class="container">
        <div class="row">
         <div class="col-lg-4">
          <div class="form-group">
            <label for="phone" >Phone </label>
            <input type="text" class="form-control" id="phone" placeholder="Phone Number" name="phone" autocomplete="off" minlength=10 maxlength=10 required>
        </div>
        </div>
          <div class="col-lg-4">

          <div class="form-group">
            <label for="add" >Address</label>
            <input type="text" class="form-control" id="add" placeholder="Your address please" rows="3" name="add" autocomplete="off" minlength=10 required>
          </div>
          </div>
          </div>
          </div>
          <div class="container">
           <div class="row">
          <div class="col-lg-4">

          <div class="form-group">
            <label for="session" >Register Number</label>
            <input type="text" class="form-control" id="session" placeholder="Register Number" name="session" autocomplete="off" minlength=10 maxlength=10 required>
          </div>
          </div>
              <div class="col-lg-4">
          <div class="form-group">
          <label for="program"  class="col-sm-2 control-label">Program</label>
           <select  class="form-control" name="program"  required id="program" name="program">          
           <option >Computer Science & Engg</option>
           <option >Electrical and Communication Engg</option>
           <option >Electrical and Electronics Engg</option>
           <option >Automobile Engg</option>
           <option >Civil Engg</option>
           <option >Commecrical Practice & Engg</option>
           <option >Mechanical Engg</option>
           </select>
          </div>  
          </div>
           </div>
          </div>

          <div class="col-lg-4">
          <div class="form-group">
          <label for="semester"  class="col-sm-2 control-label">Semester</label>
           <select  class="form-control" name="semester"  required id="semester" >           
           <option>1st</option>
           <option>2nd</option>
           <option>3rd</option> 
           <option>4th</option>
           <option>5th</option>
           <option>6th</option>
           </select>
          </div>  
          </div>
          <br><br>
          <div class="ui mini buttons col-sm-offset-3 col-sm-3">
          <button type="submit" class="ui mini positive button" name="register">Register</button>
          <div class="or"></div>
          <button type="reset" class="ui mini red button" name="back">Clear</button>
          </div> 
    
       </form>
       </div><!--form-container--> 
       </div> <!--container--> 
<?php include "includes/footer.php"; ?>
</html>