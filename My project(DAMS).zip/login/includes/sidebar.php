

     <div id="entry" class="col-lg-4">
                    <div class="panel panel-primary">
                      <div class="panel-heading">
                            <b><i class="fa fa-pencil"> </i> Entries</b>
                      </div>
                      <div class="list-group">
                      <a href="index.php" class="list-group-item">Home</a>
                        <a href="student_entry.php" class="list-group-item">Student Entry</a>
                        <a href="teacher_entry.php" class="list-group-item">Teacher Entry</a>
                        <a href="subject_entry.php" class="list-group-item">Subject Entry</a>
                        <a href="AttendenceForm.php" class="list-group-item">Do Attendance</a>
                    
                      </div>

                    </div>                    
                </div>






    
    
    
   
      
   