<?php

ob_start();

error_reporting(E_ALL & ~ E_NOTICE);
session_start();
 $pagetitle="Login Page";
?>
<?php
       if ($_POST['submit']){
        include 'connection.php';
        $email = $conn->real_escape_string($_POST['email']);
        $password = $conn->real_escape_string($_POST['password']);
        $msg="";

        if ($email == "" || $password == "")
      $msg= "<center><h5><font color='red'><i class='fa fa-info-circle' aria-hidden='true' style='color:red;'></i>&nbsp;Please Check Your Inputs !</font></h5></center>";
    else {
      $sql = $conn->query("SELECT name, password, isEmailConfirmed FROM users WHERE email='$email'");
      if ($sql->num_rows > 0) {
                $row = $sql->fetch_assoc();
                if (password_verify($password, $row['password'])) {
                    if ($row['isEmailConfirmed'] == 0)
                       $msg= "<center><h5><font color='red'><i class='fa fa-info-circle' aria-hidden='true' style='color:red;'></i>&nbsp;Email not Verified</font></h5></center>";
                    else {
                        $_SESSION['email']=$email;
                        $_SESSION['name']=$row['name'];
                        
                        header('Location:home.php');
                    }
                } else
                  $msg= "<center><h5><font color='red'><i class='fa fa-info-circle' aria-hidden='true' style='color:red;'></i>&nbsp;Invalid Credentials</font></h5></center>";
      } else {
        //echo "<span style='color:red;'><h3>Email Doesn't Exists !</h3></span>";
        $msg = "<center><h5><font color='red'><i class='fa fa-info-circle' aria-hidden='true' style='color:red;'></i>&nbsp;Email Doesn't Exists</font></h5></center>";
        }
    }

} 
?>

        <title>LogIn page</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="shortcut icon" href="../img/favicon.png" type="image/x-icon">
        <link href="css/bootstrap.css" rel='stylesheet' type='text/css'>
        <link href="css/semantic.min.css" rel="stylesheet">
        <link href="css/templatemo_style.css"  rel='stylesheet' type='text/css'>
        <link href="css/mystyle.css"  rel='stylesheet' type='text/css'>
        <link href="../signup/css/button.css"  rel='stylesheet' type='text/css'> 
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <style>
            img[src="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]{
            display:none;
            }
            </style>
        
<div class="container">

               <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 40px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Welcome to LOG IN</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                </div>
 </div>
     <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Sign In</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post" autocomplete="off" action="#">
                                <div class="form-group">
                                    <input class="form-control" placeholder="Email" name="email" type="email" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                </div>

                                    <div class="checkbox">
                                        <?php echo $msg; ?>
        							  <label>
        							    <input type="checkbox">
        							    <span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span>
        							    Remember Me
        							    </label>
        							    <br>
        							    <a href="../signup" style="float: left; text-decoration:none;color:#0dad8d;">
        							        <img  style="position:relative; left:10px;" src="https://thumb1.shutterstock.com/display_pic_with_logo/166500514/602707370/stock-vector-account-add-contact-create-friend-new-user-icon-602707370.jpg"/ alt="Forgot Password" title="Forgot Password">Create Account?
        							        </a>
        							    <a href="#" style="float: right; text-decoration:none;color:#0dad8d;">
        							        <img style="position:relative; left:22px;" src="image/forgot.png" alt="Forgot Password" title="Forgot Password">Forgot password? 
        							        </a>
        							  </div>

                                </div>
                                <button type="sumbit" name="submit" value="login" class="btn btn-lg btn-success btn-block">Log In</button>
                 
                        </form>
                        <br><a href="http://dams.cf"><button type="sumbit" name="submit" value="login" class="btn btn-lg btn-success btn-block">HOME</button> </a> 
                    </div>
                </div>
            </div>
        </div>
    </div>
          
 <?php include "includes/footer.php"; ?>