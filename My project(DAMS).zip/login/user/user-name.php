<?php
session_start();

if(isset($_SESSION['altername']))
{
    if(isset($_POST['']))
    {
        
    }
    
}
else {
    die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");
}
?>


<?php
 $pagetitle="Change User Name";
 include "includes/header.php"; 
 include "../connection.php";?>
 

 
<?php
$email= $_SESSION['email'];
if(isset($_POST['update']))
{
    $firstname= ucfirst(LTRIM(RTRIM($_POST['firstname'])));
    $sql= "UPDATE users SET name='$firstname' WHERE email='$email' ";
    $result= $conn->query($sql);
    if($result==true)
    {
        echo "&nbsp<h1>User name Updated Successfully</h1>";
    }
}
?>
 
  <?php
$sql = "SELECT * FROM users WHERE email='$email' ";
$result= $conn->query($sql);
if($result->num_rows>0)
{
    $result=$result->fetch_assoc();
    $name=$result['name'];
}
?>
 
 
<style>
    img[src="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]{
        display:none;
    }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>



<div class="container">
             <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Students Entry</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                </div>
          

<div class="form-container">
    <form action="#" method="post" role="form">

        <div class="container">
          <div class="row">
          <div class="col-lg-4">
          <div class="form-group">
            <label for="name" > User Name </label>
            <input type="text" class="form-control" required id="firstname" placeholder="User name"  name="firstname" autocomplete="off" value="<?php echo $name; ?>">
            <br><br><button type="submit" name="update" class="ui blue tiny button " style="font-size:16px"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> &nbsp;Update</button>
          </div>
          </div>
         </div>
        </div>  <!-- col-container-->
        </form>
        </div>  <!-- form-container-->
        </div> <!-- container-->
          
              
</div><!--container-->
<?php include "includes/footer.php"; ?>
