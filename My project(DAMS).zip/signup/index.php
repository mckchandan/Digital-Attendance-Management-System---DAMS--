<html>
<head>
<style>
            img[src="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]{
display:none;
}
</style>
</head>
</html>
<?php
	$msg = "";
	use PHPMailer\PHPMailer\PHPMailer;
	

	if (isset($_POST['submit'])) {
		$con = new mysqli('localhost', 'id4172165_damsonline', 'damsonline', 'id4172165_dams');

		$name = LTRIM(RTRIM(ucwords($con->real_escape_string($_POST['username']))));
		$email = LTRIM(RTRIM(strtolower($con->real_escape_string($_POST['email']))));
		$password = $con->real_escape_string($_POST['password']);
		$cPassword = $con->real_escape_string($_POST['cpassword']);

		if ($name == "" || $email == "" || $password != $cPassword)
			$msg = "Please check your inputs!";
		else {
			$sql = $con->query("SELECT id FROM users WHERE email='".$email."'");
			if ($sql->num_rows > 0) {
				$msg = "Email address provided by you is already in use.<br>
				Please enter a different email address.";
			} else {
				$token = 'qwertzuiopasdfghjklyxcvbnmQWERTZUIOPASDFGHJKLYXCVBNM0123456789!$/()*';
				$token = str_shuffle($token);
				$token = substr($token, 0, 10);

				$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

				$con->query("INSERT INTO users (name,email,password,isEmailConfirmed,token)
					VALUES ('$name', '$email', '$hashedPassword', '0', '$token');");

				include_once "PHPMailer/PHPMailer.php";
                include_once "PHPMailer/Exception.php";
                include_once "PHPMailer/SMTP.php";

                $mail = new PHPMailer();
                
                $mail->IsSMTP(); 
                $mail->isHTML(true);
                $mail->SMTPDebug = 0; 
                $mail->SMTPAuth = true; 
                $mail->SMTPSecure = "ssl"; 
                $mail->Host = "smtp.gmail.com"; 
                $mail->Port = '465'; 
                $mail->Username ="dams.cf@gmail.com"; 
                $mail->Password ="zldarbjsnqgwudhj"; 
                $mail->setFrom('report-us@dams.cf');
                $mail->addAddress($email, $name);
                $mail->Subject = "Thank you";
                //$mail->addAttachment('images/logo.png','logo.png');
                 $mail->Body = "
                 
                  <img src='https://damsonline.000webhostapp.com/img/favicon.png' align='center' width='18%' height='18%' alt='logo'>
                    <font face='Helvetica'><p>Thanks for registering with DAMS. Please click this link to complete your registration:<br><br>
                    <a href='http://dams.cf/signup/confirm.php?email=$email&token=$token'>https://dams.cf/signup/verify</a>
                    <br><br>
                    We are really looking forward to working with you.<br><br>
                    Regards :<br>
                    <b>The DAMS Group</b><br>
                    www.dams.cf<br><br>
                    </p>
                    <a href='https://www.facebook.com/DAMSGroupIN/'><img src='https://cbdspain.com/wp-content/uploads/2017/12/099085-glossy-black-3d-button-icon-social-media-logos-facebook-logo-square.png' width='9%' height='9%' alt='facebook'></a>
                    </font>

                ";

                if ($mail->send())
                    $msg = "You have been Successfully Registered! Please verify your Email ! to Acctivate your Account";
                else
                    $msg = "$mail->ErrorInfo";

                 
			}
		}
	}
?>



<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>
    
            <!-- ===== Page Loader ====== -->
            
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
        <script type="text/javascript">
        $(window).load(function() {
        $(".loader").fadeOut("slow");
        });
        </script> 
        
        <style>
        .loader {
            position: fixed;
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background: url('https://i.pinimg.com/originals/d1/2c/ae/d12cae398bdddd5d6daee9ec6c491333.gif') 50% 50% no-repeat rgb(249,249,249);
            opacity: .8;
        }
        </style>
        
        <!-- End of Loader -->

        <link rel="shortcut icon" href="../img/favicon.png" type="image/x-icon">
        
		<link href="css/bootstrap.css" rel='stylesheet' type='text/css'>

        <link href="css/semantic.min.css" rel="stylesheet">

        <link href="css/templatemo_style.css"  rel='stylesheet' type='text/css'>

        <link href="css/mystyle.css"  rel='stylesheet' type='text/css'> 

        <link href="css/button.css"  rel='stylesheet' type='text/css'>

        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        
    

            <!-- password valodation -->
            
		<script type="text/javascript">
		        var check = function() {
		            var passwordTextBox = document.getElementById("password");
        var password1 = passwordTextBox.value;

        if (!/\d/.test(password1) || !/[a-z]/.test(password1) || !/[A-Z]/.test(password1) || !password1.length >= 8){

        document.getElementById("message").innerHTML = "<center><b>Password Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters</b><center>";
        document.getElementById("message").style.color="red";
    } else
		            
		  if (document.getElementById('password').value == document.getElementById('cpassword').value) {
		    document.getElementById('message').innerHTML = "";
		  } else {
		    document.getElementById('message').style.color = 'red';
		    document.getElementById('message').innerHTML = "<b><center>Your passwords doesn't match.</b></center>";
		  }
		}
		
		 </script>
		 
		 <!--End of password valodation -->

</head>
<body>
<div class="loader"></div>
	<div class="container">



               <div class="row">

                    <div class="templatemo-line-header" style="margin-top: 40px;" >

                        <div class="text-center">

                            <hr class="team_hr hr_gray"/><span class="span_blog txt_darkgrey txt_orange">&emsp;&emsp;Welcome to SIGN UP</span>

                            <hr class="team_hr team_hr_right hr_gray" />

                        </div>

                    </div>

                </div>

 </div>

     <div class="container">

        <div class="row">

            <div class="col-md-4 col-md-offset-4">
            
            
			

                <div class="login-panel panel panel-default">

                    <div class="panel-heading">
                        <p align="center"><font face="Calibri (Body)" size="2.5">  <?php echo $msg; ?> </font></p>

                        <h3 class="panel-title" align="center"><b>Create Your Acoount</b></h3>

                    </div>

                    <div class="panel-body">

                        <form role="form" method="post" autocomplete="off" action="#">

                                <div class="form-group">

                                    <input class="form-control" placeholder="User name" name="username" type="username" autofocus required title="username">

                                </div>

                                <div class="form-group">

                                    <input class="form-control" placeholder="Email" name="email" type="email" autofocus required title="Email that is used to Login ">

                                </div>

                                <div class="form-group">

                                    <input class="form-control" placeholder="Password" name="password" id="password" type="password" value="" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>

                                </div>

                                 <div class="form-group">

                                    <input class="form-control" placeholder="Confirm password" name="cpassword" id="cpassword" type="password" value="" required onkeyup='check();'>
                                    <span id='message'></span>

                                </div>

                                <div class="checkbox">

                                    <div class="checkbox">
        							  <label>
        							    <input type="checkbox" checked="true">
        							    <span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span>
        							    Agree to the Terms of Services.
        							    </label>
        							</div>

                                </div>

                                <button type="sumbit" name="submit" value="login" class="btn btn-lg btn-success btn-block">Sign Up</button>  

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>
</body>
</html>