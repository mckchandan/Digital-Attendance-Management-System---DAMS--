<?php
	

require 'phpmailer/PHPMailerAutoload.php';

 
// creates object
$mail = new PHPMailer(); 



$mail->IsSMTP(); 
$mail->isHTML(true);
$mail->SMTPDebug = 0; 
$mail->SMTPAuth = true; 
$mail->SMTPSecure = "ssl"; 
$mail->Host = "smtp.gmail.com"; 
$mail->Port = '465'; 
$mail->AddAddress('dhanushbl007@gmail.com');
$mail->Username ="dams.cf@gmail.com"; 
$mail->Password ="zldarbjsnqgwudhj"; 
$mail->SetFrom("report-us@gmail.com","Dams Group");
$mail->AddReplyTo("report-us@gmail.com","Dams Group");
$mail->Subject = "Thank You";
$mail->Body = "
<html>
<head>
	<title>table</title>
	<style>
		table{
			border-collapse: collapse;
		}
		table th {
			text-align: left;
			background-color: #3a6070;
			color: #fff;
			padding: 4px 30px 4px 8px;
		}
		table td{
			border: 1px solid #e3e3e3;
			padding: 4px 8px;
		}
		table tr:nth-child(odd) td{
			background-color: #000;
		}
	</style>
</head>
<body>
	<table>
		<tr>
			<th>Name</th>
			<th>Regno</th>
		</tr>
		<tr>
			<td>Dhanush</td>
			<td>108cs15007</td>
		</tr>
		<tr>
			<td>Dhanush</td>
			<td>108cs15007</td>
		</tr>
		<tr>
			<td>Dhanush</td>
			<td>108cs15007</td>
		</tr>
	</table>
</body>
</html>
    ";
$mail->AltBody = "hlo";
if($mail->Send())
echo "<h1>Hi, Your mail successfully sent to</h1>";
else
echo "".$mail->ErrorInfo;
?>
