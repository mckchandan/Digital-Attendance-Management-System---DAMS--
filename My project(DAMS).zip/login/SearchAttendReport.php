<?php
session_start();

             if(isset($_SESSION['name'])){
              $username=($_SESSION['email']);
              $username=($_SESSION['name']);
            }
            else{
              die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");
            }
 $pagetitle="Student Page";
      ?>

<?php
  $pagetitle="student Report";
  include "includes/header.php"; ?>
  <div class="container">
         <div class="row">
                 <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Individual Searching</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                </div>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include("connection.php");
echo $teacher_msg;
if($status)
          {
?>
    <div class="form-container">

    <form method="post" action="Search_Rpt.php" role="form" class="search-form" style="width: 70%">
    <div class="container">
        <!-- <div class="row"> -->
         <div class="col-lg-8">
          <div class="form-group">

           <label for="student" >Student Name </label>
          <?php
          $qs= $conn->query("select * from student_entry" );	
          echo "<select name='stdname' class='form-control' >";			

          while($stid=$qs->fetch_assoc())
          {				
           echo '<option>' .$stid["studentname"]. '</option>';
           }
          echo "</select>";

          ?>
         </div>
        <div class="form-group">
          <label for="session" > Subject</label>
          <?php
          
          $kgid= $userId;
          $qs1=$conn->query("select * from subject_entry WHERE kgid='$kgid'");	
          echo "<select name='subject' class='form-control' required>";			
          while($subject=$qs1->fetch_assoc())
          {		
          		
           echo '<option>' .$subject["subject_name"]. '</option>';
           }
          echo "</select>";

          ?>
          </div>
        </div>
        
          <div class="col-lg-8"><br>
          <button type="submit" class="btn btn-success btn-lg btn-block" value="Search" name="search">Search</button>
          </div>
          </div>
<?php } ?>
          </form>
          </div> <!--form-container--> 
          </div><!--container--> 
          <?php include "includes/footer.php"; ?>