<?php
$username="id4172165_damsonline";
$password="damsonline";
$server="localhost";
$db="id4172165_dams";
$con=new mysqli($server,$username,$password,$db);
if(!$con)
{
echo "could not connect".mysql_error();
}

?>