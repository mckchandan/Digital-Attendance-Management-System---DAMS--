
<?php
 $pagetitle="Updating-Teacher's Record";
 include "includes/header.php";
 include "connection.php";
  ?>

 <?php

    if (isset($_POST['update']))
      {
      $teachername = ucfirst(LTRIM(RTRIM($_POST['name'])));
      $dob = $_POST['dob'];
      $email = LTRIM(RTRIM($_POST['email']));
      $phone= $_POST['phone'];
      $degree= $_POST['degree'];
      $salary= $_POST['salary'];
      $address= ucfirst(LTRIM(RTRIM($_POST['address'])));
      $id= $_GET['teacher_id'];

        $sql = "UPDATE teacher_entry SET teachername='".$teachername."',dob='".$dob."',email='".$email."',phone='".$phone."',address='".$address."',degree='".$degree."',salary='".$salary."' WHERE kgid='".$id."'";

      if ($conn->query($sql) === TRUE) {
        echo "<br><div class='container'>
                    <div class='alert alert-success alert-dismissible'>
                    <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                    <h4 align='center'>&emsp;Success!, Teacher Information Updated Successfully</h4> 
                    </div>
                    </div>
                ";
      } else {
          echo "Error: " . $sql . "<br>" . $conn->error;
      }

      }
       ?>
      

    


<div class="container">
   <div class="row">
                    <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Update The Teacher</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                    </div>
                </div>


        <?php 
        if (isset($_GET['teacher_id'])) {
          $t_id = $_GET['teacher_id'];
        }
             $sql = "SELECT  * FROM  teacher_entry WHERE kgid='".$t_id."' ";
            $result = $conn->query($sql);
      
          if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc())
          {

          ?>            

<div class="form-container">

    <form method="post" role="form" action="teacher_update.php?teacher_id=<?php echo $row['kgid']; ?>">
    <div class="container">
    <div class="row">
    <div class="col-lg-3">
          <div class="form-group">
            <label for="name" > Teacher Name (*)</label>
            <input type="text" class="form-control" required id="name" placeholder="First Name" name="name" value="<?php echo $row['teachername']; ?>">
          </div>
    </div>
    <div class="col-lg-3">
          <div class="form-group">
            <label for="dob"> Date Of Birth </label>
            <input type="date" class="form-control" id="dob" name="dob" value="<?php echo $row['dob']; ?>">
          </div>
    </div>
    </div>
    </div>
    <div class="container">
    <div class="row">
    
    <div class="col-lg-3">
          <div class="form-group">
          <label for="gender" >Gender</label>
           
            <input type="text" class="form-control" id="sex" name="gender"  value="<?php echo $row['gender']; ?>" disabled="TRUE">
          </div>
     </div>
     <div class="col-lg-3">
          <div class="form-group">
            <label for="email">Email address </label>
            <input type="email" class="form-control" required id="email" placeholder=" Email" name="email" value="<?php echo $row['email']; ?>">
          </div>
          </div>
     </div>
     </div>

     <div class="container">
    <div class="row">
    
    <div class="col-lg-3">
          <div class="form-group">
            <label for="phone">Phone </label>
            <input type="text" class="form-control" id="phone" placeholder="Phone Number" name="phone" value="<?php echo $row['phone']; ?>">
          </div>
    </div>
    <div class="col-lg-3">
           <div class="form-group">
          <label for="degree" >Degree (*)</label>
           <select  class="form-control" name="degree"  required id="degree" name="degree">
           <option></option>
           <option >Bachelor</option>
           <option >Master</option>
           <option >M.Phil</option>
           <option >P.HD</option>
           </select>
          </div>
    </div>
    </div>
    </div>
    <div class="container">
    <div class="row">

    <div class="col-lg-3">
          <div class="form-group">
            <label for="salary"> Salary </label>
            <input type="text" class="form-control" required id="salary" placeholder=" Enter salary"  name="salary" value="<?php echo $row['salary']; ?>">
          </div>
    </div>
    <div class="col-lg-3">
          <div class="form-group">
            <label for="address">Address</label>
            <textarea class="form-control" id="address" placeholder="Your address please" rows="3" name="address"><?php echo $row['address']; ?></textarea>
          </div>
    </div>
    </div>
    </div>


          <div class="ui mini buttons col-sm-offset-3 col-sm-3">
          <button type="submit" class="ui mini positive button" name="update">Update</button>
          <div class="or"></div>
          <a href="teacher.php" type="submit" class="ui mini button" name="back">Back</a>
          </div>
      
       </form>
        <?php }} ?>

           </div><!--form-container-->  
           </div><!--container-->     
<?php include "includes/footer.php"; ?>
