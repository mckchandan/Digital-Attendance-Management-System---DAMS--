<?php
session_start();

             if(isset($_SESSION['name'])){
              $username=($_SESSION['email']);
              $userId=($_SESSION['name']);
            }
            else{
              die("<center><h1> *******  Direct access is not allowed *******</h1>  </center>");
            }
 $pagetitle="Student Page";
      ?>
<?php  
 error_reporting(E_ALL ^ E_DEPRECATED);
$pagetitle="AttendenceForm";
  include "includes/header.php"; 
include("connection.php"); ?>
 <div class="container">
              <div class="row">
                 <div class="templatemo-line-header" style="margin-top: 0px;" >
                        <div class="text-center">
                            <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Attendance Form</span>
                            <hr class="team_hr team_hr_right hr_gray" />
                        </div>
                  </div>
                </div>
<?php 
echo $teacher_msg;
?>

<!-- ==== Bootstrap Radio Button ====== -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="../signup/css/button.css" rel="stylesheet">

<!-- ==== Bootstrap Radio Button ====== -->




<div class="form-container">
    <form method="post" action="saveattendence.php" role="form">
     <!-- <div class="container"> -->
     <div class="col-lg-3">
      <div class="form-group">
          
    <?php
    if($status)
    {
      $sql=$conn->query("select * from student_entry");
      
      echo "<select class='form-control' name='studentname' >";      
      while($row=$sql->fetch_assoc())
      {       
       echo"<option> ".$row['studentname']." </option>";
       }
      echo "</select>"."<br>";
      ?>
      </div>
      </div> <!--col-lg-4-->


       <div class="col-lg-3">
      <?php
      $sql2=$conn->query("select * from subject_entry WHERE kgid='$userId' ");  
      echo "<select class='form-control' name='subjname'>";     
      while($subject=$sql2->fetch_assoc())
      {       
       echo"
       <option> ".$subject['subject_name']." </option>";
       }
      echo "</select>";
      ?>
      </div> <!--col-lg-4-->
      
  <!-- ==== Bootstrap Radio Button ====== -->    
      
    
    <div class="col-sm-12">
        <div class="radio">
          <label><font size="3px;">
            <input type="radio" name="attendence" value="1" checked>
            <span class="cr"><i class="cr-icon fa fa-check-circle" style="font-size:20px; positio:relative; left:-0px;"></i></span>
            &emsp;<b>Present</b>
          </label>
          </div>
          <div class="radio">
          <label>
            <input type="radio" name="attendence" value="0" >
            <span class="cr"><i class="cr-icon fa fa-ban" style="font-size:20px; positio:relative; left:-0px;"></i></span>
            &emsp;<b>Absent</b></font>
           
          </label>
    </div>
    </div>

      
 <!-- ==== Bootstrap Radio Button ====== -->     
      
      <button type="submit" name="save" value="Save" class="btn btn-success btn-sm"><h4>Save</h4></button>
   <?php } ?>
 </form>
 </div> <!--form-container-->
</div><!--container-->
<?php include "includes/footer.php"; ?>